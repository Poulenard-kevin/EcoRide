<?php
$cfg['blowfish_secret'] = 'WRqPyTKd0XJUr8615tKDzZTClYyMz7JfPIUemsNVtkY=';
$i = 1;
$cfg['Servers'][$i]['auth_type'] = 'cookie';
$cfg['Servers'][$i]['host'] = 'db_ecoride';
