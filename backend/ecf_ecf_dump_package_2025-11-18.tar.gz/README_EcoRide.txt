=== EcoRide — Instructions pour l'évaluateur ===

Prérequis :
- Docker & Docker Compose installés

1) Démarrer les services :
   docker compose -f ecoride-docker/docker-compose.yml up -d

2) Importer la base de données :
   Option A (phpMyAdmin) :
     - Ouvrir http://localhost:8082
     - Se connecter en root : root / rootpassword_ecoride
     - Aller sur sf_EcoRide -> Importer -> choisir ecf_dump_with_user.sql (ou .gz) -> Exécuter

   Option B (CLI) :
     mysql -u root -p'rootpassword_ecoride' sf_EcoRide < ecf_dump_with_user.sql

3) Accès applicatif :
   - Frontend : http://localhost:3000
   - Backend API : http://127.0.0.1:8000
   - phpMyAdmin : http://localhost:8082

4) Identifiants DB à utiliser pour l'application (non-root) :
   - utilisateur : ecf_user
   - mot de passe : UnMotDePasseFort!2025
   - DATABASE_URL exemple :
     mysql://ecf_user:UnMotDePasseFort!2025@db_ecoride:3306/sf_EcoRide

Remarques :
- Ne pas partager le mot de passe root. Fournir uniquement ecf_user aux évaluateurs.
- Si l'import via phpMyAdmin échoue (taille limite), utiliser la méthode CLI.
